import React, { useEffect, useMemo, useState } from "react";
import { API_BASE, fetchUnidadesNegocio } from "../api";
import Swal from "sweetalert2";

const MAX_CV_MB = 25;

export default function PostulacionForm() {
  const [form, setForm] = useState({
    nombre: "",
    apellido: "",
    correo: "",
    telefono: "",
    puesto_id: "",
    unidad_id: "",
    nota: "",

    // Nuevos campos
    dni: "",
    fecha_nacimiento: "",
    estado_civil: "",
    hijos: "", // será "true" o "false" como string
    domicilio_residencia: "",
    localidad: "",
  });
  const [cv, setCv] = useState(null);

  const [unidades, setUnidades] = useState([]);
  const [loadingUnidades, setLoadingUnidades] = useState(true);
  const [errUnidades, setErrUnidades] = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoadingUnidades(true);
        setErrUnidades("");
        const raw = await fetchUnidadesNegocio();

        const onlyActive = raw
          .filter((u) => u?.activo)
          .map((u) => ({
            id: u.id,
            nombre: u.nombre,
            descripcion: u.descripcion,
            activo: true,
            puestos: Array.isArray(u.puestos)
              ? u.puestos
                  .filter((p) => p?.activo)
                  .map((p) => ({
                    id: p.id,
                    nombre: p.nombre,
                    descripcion: p.descripcion,
                    unidad_id: p.unidad_id,
                  }))
              : [],
          }));

        if (mounted) {
          setUnidades(onlyActive);
          if (onlyActive.length === 1) {
            const unica = onlyActive[0];
            setForm((f) => ({ ...f, unidad_id: String(unica.id), puesto_id: "" }));
          }
        }
      } catch (err) {
        if (mounted) setErrUnidades(err.message || "No se pudieron cargar las unidades.");
      } finally {
        if (mounted) setLoadingUnidades(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  const puestosDeUnidad = useMemo(() => {
    const uid = Number(form.unidad_id);
    if (!uid) return [];
    const u = unidades.find((x) => x.id === uid);
    return u?.puestos || [];
  }, [form.unidad_id, unidades]);

  // ===== Validaciones =====
  const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);

  const validateField = (name, value) => {
    switch (name) {
      case "nombre":
      case "apellido":
      case "telefono":
      case "dni":
      case "fecha_nacimiento":
      case "estado_civil":
      case "hijos":
      case "domicilio_residencia":
      case "localidad":
        return value ? "" : "Requerido";
      case "correo":
        if (!value.trim()) return "Requerido";
        if (!isEmail(value.trim())) return "Formato de email inválido";
        return "";
      case "unidad_id":
      case "puesto_id":
        return value ? "" : "Requerido";
      case "cv":
        if (!cv) return "Adjuntá tu CV en PDF";
        if (cv.type !== "application/pdf") return "El archivo debe ser PDF";
        if (cv.size > MAX_CV_MB * 1024 * 1024) return `Máximo ${MAX_CV_MB}MB`;
        return "";
      default:
        return "";
    }
  };

  const validateAll = () => {
    const e = {};
    [
      "nombre", "apellido", "correo", "telefono",
      "unidad_id", "puesto_id",
      "dni", "fecha_nacimiento", "estado_civil",
      "hijos", "domicilio_residencia", "localidad"
    ].forEach((field) => {
      const msg = validateField(field, form[field]);
      if (msg) e[field] = msg;
    });

    const cvMsg = validateField("cv", cv);
    if (cvMsg) e.cv = cvMsg;
    return e;
  };

  const updateFieldAndMaybeClearError = (name, value) => {
    setErrors((prev) => {
      const next = { ...prev };
      if (next[name]) {
        const msg = validateField(name, value);
        if (!msg) delete next[name];
        else next[name] = msg;
      }
      if (name === "unidad_id" && next["puesto_id"]) {
        const puestoMsg = validateField("puesto_id", "");
        if (!puestoMsg) delete next["puesto_id"];
        else next["puesto_id"] = puestoMsg;
      }
      return next;
    });
  };

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((f) => {
      if (name === "unidad_id") {
        updateFieldAndMaybeClearError(name, value);
        return { ...f, unidad_id: value, puesto_id: "" };
      }
      updateFieldAndMaybeClearError(name, value);
      return { ...f, [name]: value };
    });
  };

  const onFile = (e) => {
    const file = e.target.files?.[0] || null;
    setCv(file);
    setErrors((prev) => {
      const next = { ...prev };
      if (next.cv) {
        const msg = validateField("cv", file);
        if (!msg) delete next.cv;
        else next.cv = msg;
      }
      return next;
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = validateAll();
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) {
      const first = Object.keys(newErrors)[0];
      const el = document.querySelector(`[data-field="${first}"]`);
      if (el) el.focus();
      return;
    }

    try {
      setLoading(true);

      const fd = new FormData();
      fd.append("nombre", form.nombre.trim());
      fd.append("apellido", form.apellido.trim());
      fd.append("correo", form.correo.trim());
      fd.append("telefono", form.telefono.trim());
      fd.append("puesto_id", String(form.puesto_id).trim());
      fd.append("unidad_id", String(form.unidad_id).trim());
      fd.append("nota", form.nota.trim());
      fd.append("cv", cv, cv.name);

      // Nuevos campos
      fd.append("dni", form.dni.trim());
      fd.append("fecha_nacimiento", form.fecha_nacimiento);
      fd.append("estado_civil", form.estado_civil.trim());
      fd.append("hijos", form.hijos === "true" ? "true" : "false");
      fd.append("domicilio_residencia", form.domicilio_residencia.trim());
      fd.append("localidad", form.localidad.trim());

      const res = await fetch(`${API_BASE}/postulaciones`, {
        method: "POST",
        headers: { Accept: "application/json" },
        body: fd,
      });

      if (!res.ok) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Hubo un problema al enviar tu postulación. Intentalo nuevamente.",
        });
        return;
      }

      setForm({
        nombre: "",
        apellido: "",
        correo: "",
        telefono: "",
        puesto_id: "",
        unidad_id: form.unidad_id,
        nota: "",
        dni: "",
        fecha_nacimiento: "",
        estado_civil: "",
        hijos: "",
        domicilio_residencia: "",
        localidad: "",
      });
      setCv(null);
      setErrors({});
      const fileInput = document.getElementById("cv-input");
      if (fileInput) fileInput.value = "";

      Swal.fire({
        icon: "success",
        title: "¡Postulación enviada!",
        text: "Gracias por postularte. Te estaremos contactando pronto.",
        confirmButtonText: "Aceptar",
        customClass: { confirmButton: "btn btn-enviar" },
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate>
      {/* Datos personales */}
      <div className="row g-3">
        <div className="col-md-6">
          <label className="form-label">Nombre</label>
          <input
            data-field="nombre"
            className={`form-control ${errors.nombre ? "is-invalid" : ""}`}
            name="nombre"
            value={form.nombre}
            onChange={onChange}
            placeholder="Tu nombre"
          />
          {errors.nombre && <div className="invalid-feedback">{errors.nombre}</div>}
        </div>

        <div className="col-md-6">
          <label className="form-label">Apellido</label>
          <input
            data-field="apellido"
            className={`form-control ${errors.apellido ? "is-invalid" : ""}`}
            name="apellido"
            value={form.apellido}
            onChange={onChange}
            placeholder="Tu apellido"
          />
          {errors.apellido && <div className="invalid-feedback">{errors.apellido}</div>}
        </div>
      </div>

      <div className="row g-3 mt-1">
        <div className="col-md-6">
          <label className="form-label">Correo</label>
          <input
            data-field="correo"
            className={`form-control ${errors.correo ? "is-invalid" : ""}`}
            type="email"
            name="correo"
            value={form.correo}
            onChange={onChange}
            placeholder="tu_correo@example.com"
          />
          {errors.correo && <div className="invalid-feedback">{errors.correo}</div>}
        </div>

        <div className="col-md-6">
          <label className="form-label">Teléfono</label>
          <input
            data-field="telefono"
            className={`form-control ${errors.telefono ? "is-invalid" : ""}`}
            name="telefono"
            value={form.telefono}
            onChange={onChange}
            placeholder="353 123 4567"
          />
          {errors.telefono && <div className="invalid-feedback">{errors.telefono}</div>}
        </div>
      </div>

      {/* Nuevos campos */}
      <div className="row g-3 mt-1">
        <div className="col-md-6">
          <label className="form-label">DNI</label>
          <input
            className={`form-control ${errors.dni ? "is-invalid" : ""}`}
            name="dni"
            value={form.dni}
            onChange={onChange}
            placeholder="Ej: 12345678"
          />
          {errors.dni && <div className="invalid-feedback">{errors.dni}</div>}
        </div>

        <div className="col-md-6">
          <label className="form-label">Fecha de nacimiento</label>
          <input
            className={`form-control ${errors.fecha_nacimiento ? "is-invalid" : ""}`}
            type="date"
            name="fecha_nacimiento"
            value={form.fecha_nacimiento}
            onChange={onChange}
          />
          {errors.fecha_nacimiento && <div className="invalid-feedback">{errors.fecha_nacimiento}</div>}
        </div>
      </div>

      <div className="row g-3 mt-1">
        <div className="col-md-6">
          <label className="form-label">Estado civil</label>
          <select
            className={`form-select ${errors.estado_civil ? "is-invalid" : ""}`}
            name="estado_civil"
            value={form.estado_civil}
            onChange={onChange}
          >
            <option value="">Seleccionar</option>
            <option value="soltero">Soltero</option>
            <option value="casado">Casado</option>
            <option value="concubinato">Concubinato</option>
            <option value="viudo">Viudo</option>
          </select>
          {errors.estado_civil && <div className="invalid-feedback d-block">{errors.estado_civil}</div>}
        </div>

        <div className="col-md-6">
          <label className="form-label">¿Tiene hijos?</label>
          <select
            className={`form-select ${errors.hijos ? "is-invalid" : ""}`}
            name="hijos"
            value={form.hijos}
            onChange={onChange}
          >
            <option value="">Seleccionar</option>
            <option value="true">Sí</option>
            <option value="false">No</option>
          </select>
          {errors.hijos && <div className="invalid-feedback d-block">{errors.hijos}</div>}
        </div>
      </div>

      <div className="row g-3 mt-1">
        <div className="col-md-6">
          <label className="form-label">Domicilio de residencia</label>
          <input
            className={`form-control ${errors.domicilio_residencia ? "is-invalid" : ""}`}
            name="domicilio_residencia"
            value={form.domicilio_residencia}
            onChange={onChange}
            placeholder="Calle, número, piso/depto"
          />
          {errors.domicilio_residencia && <div className="invalid-feedback">{errors.domicilio_residencia}</div>}
        </div>

        <div className="col-md-6">
          <label className="form-label">Localidad</label>
          <input
            className={`form-control ${errors.localidad ? "is-invalid" : ""}`}
            name="localidad"
            value={form.localidad}
            onChange={onChange}
            placeholder="Tu localidad"
          />
          {errors.localidad && <div className="invalid-feedback">{errors.localidad}</div>}
        </div>
      </div>

      {/* Nota (único campo opcional) */}
      <div className="mt-3">
        <textarea
          className="form-control"
          name="nota"
          rows={3}
          value={form.nota}
          onChange={onChange}
          maxLength={500}
          placeholder="Contanos brevemente sobre vos (opcional)"
        />
        <div className="form-text text-end">{form.nota.length}/500</div>
      </div>

      {/* CV */}
      <div className="mt-3">
        <label className="form-label">CV (PDF)</label>
        <input
          id="cv-input"
          data-field="cv"
          className={`form-control ${errors.cv ? "is-invalid" : ""}`}
          type="file"
          accept="application/pdf"
          onChange={onFile}
        />
        <div className="form-text">Hasta {MAX_CV_MB}MB.</div>
        {errors.cv && <div className="invalid-feedback d-block">{errors.cv}</div>}
      </div>

      <div className="d-grid mt-4">
        <button className="btn btn-enviar" type="submit" disabled={loading}>
          {loading ? (
            <>
              <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
              Enviando...
            </>
          ) : (
            <>Enviar <i className="fa-solid fa-paper-plane"></i></>
          )}
        </button>
      </div>
    </form>
  );
}
