import React from "react";
import PostulacionForm from "./components/PostulacionesForm";

export default function App() {
  return (
    <div className="container py-4">
      {/* Header con logo + título */}
      <header className="d-flex flex-column align-items-center mb-4">
        {/* Reemplazá /logo.png por tu logo */}
        <img
          src="/logo.png"
          alt="Logo"
          style={{ height: 64 }}
          className="mb-2"
          onError={(e) => { e.currentTarget.style.display = "none"; }}
        />
      </header>

      {/* Contenido principal */}
      <div className="row justify-content-center">
        <div className="col-12 col-lg-8 col-xxl-6">
          <div className="card card-ghost rounded-4">
            <div className="card-body p-4 px-md-5">
              <h1 className="text-center fs-1 titulo">
                Grupo DON EMILIO
              </h1>
              <p className="text-center text-secondary">
                Trabaja con nosotros
              </p>
              <hr className="hr-solid" />
              <PostulacionForm />
            </div>
          </div>

          {/* Nota al pie */}
          <p className="text-center text-secondary mt-3 mb-0" style={{ fontSize: ".925rem" }}>
            <i className="fa-solid fa-lock me-1"></i>
            Tus datos se envían de forma segura.
            <span className="d-block" style={{ fontSize: ".75rem" }}>Powered By Don Emilio DEVs</span>
          </p>
        </div>
      </div>
    </div>
  );
}
